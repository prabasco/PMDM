package com.example.productosapp

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ejemplo.productosapp.Producto
import com.ejemplo.productosapp.productos

class MainActivity : ComponentActivity() {

    private val tag = "CicloVida"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(tag, "onCreate")
        setContent {
            MaterialTheme {
                PantallaProductos()
            }
        }
    }

    override fun onStart()   { super.onStart();   Log.d(tag, "onStart") }
    override fun onResume()  { super.onResume();  Log.d(tag, "onResume") }
    override fun onPause()   { super.onPause();   Log.d(tag, "onPause") }
    override fun onStop()    { super.onStop();    Log.d(tag, "onStop") }
    override fun onDestroy() { super.onDestroy(); Log.d(tag, "onDestroy") }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaProductos() {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Nuestros productos") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(productos, key = { it.id }) { producto ->
                TarjetaProducto(producto)
            }
        }
    }
}

@Composable
fun TarjetaProducto(producto: Producto) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(producto.imagen),
                contentDescription = producto.nombre,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(producto.nombre, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(producto.descripcion, style = MaterialTheme.typography.bodyMedium)
                Text("%.2f €".format(producto.precio), style = MaterialTheme.typography.titleSmall)
            }
        }
    }
}