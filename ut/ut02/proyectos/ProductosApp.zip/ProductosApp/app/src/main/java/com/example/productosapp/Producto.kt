package com.ejemplo.productosapp

import androidx.annotation.DrawableRes

data class Producto(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val precio: Double,
    @DrawableRes val imagen: Int
)