package com.ejemplo.productosapp

import com.example.productosapp.R

val productos = listOf(
    Producto(1, "Manzanas", "Bolsa de 1 kg de manzanas rojas", 2.49, R.drawable.manzana),
    Producto(2, "Café", "Café molido natural, 250 g", 3.95, R.drawable.cafe),
    Producto(3, "Auriculares", "Auriculares inalámbricos Bluetooth", 29.90, R.drawable.auriculares),
    Producto(4, "Mochila", "Mochila de 20 L resistente al agua", 24.50, R.drawable.mochila),
    Producto(5, "Libreta", "Libreta A5 de 100 hojas", 1.99, R.drawable.libreta)
)